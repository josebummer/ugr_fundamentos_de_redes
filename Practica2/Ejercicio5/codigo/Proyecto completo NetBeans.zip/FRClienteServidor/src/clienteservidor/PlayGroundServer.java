/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienteservidor;

import clienteservidor.securestream.SecureStreamServidor;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;

/**
 *
 * @author guillermo
 */
public class PlayGroundServer {
    public static void main(String[] args){
        final int PORT = 7777;
        ServerSocket serverSocket;
        try{
            serverSocket = new ServerSocket(PORT);
            Socket socketServicio;
            do{
                socketServicio = serverSocket.accept();
                SecureStreamServidor secureStreamServidor = new SecureStreamServidor(socketServicio);
                
                byte[] bufferEntrada = new byte[2048];
                int n;
                String msg_s = "Adios mundo";
                
                String msg_r = secureStreamServidor.readUTF();
                System.out.println("#: " + msg_r);
                msg_r = secureStreamServidor.readUTF();
                System.out.println("#: " + msg_r);
                /*
                n = secureStreamServidor.read(bufferEntrada, 0, bufferEntrada.length);
                System.out.println("ReadCiph: " + n);
                if(n>0){
                    String msg_r = new String(bufferEntrada, 0, n);
                    System.out.println(msg_r);
                }
                */
                //secureStreamServidor.write(msg_s.getBytes(), 0, msg_s.getBytes().length);
                secureStreamServidor.writeUTF(msg_s);
                
                secureStreamServidor.close();
                socketServicio.close();
                
            }while(true);
        }catch(Exception e){
            System.err.println(e.toString());
            e.printStackTrace();
        }
    }
}
