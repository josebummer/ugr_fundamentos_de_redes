/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clienteservidor;

import clienteservidor.securestream.SecureStreamCliente;
import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author guillermo
 */
public class PlayGroundClient {
    public static void main(String[] args) throws IOException{
        final int PORT = 7777;
        final String HOST = "localhost";
        Socket socketServicio;
        
        try{
            socketServicio = new Socket(HOST,PORT);
            SecureStreamCliente secureStreamCliente = new SecureStreamCliente(socketServicio);
            
            //secureStreamCliente.testSize();
            //Escribo
            String msg = "Hola mundo guapo ahi bien larga la cadena";
            String msg2 = "Otra cadena ahi";
            //secureStreamCliente.write(msg.getBytes(), 0, msg.getBytes().length);
            secureStreamCliente.writeUTF(msg);
            secureStreamCliente.writeUTF(msg2);
                       
            
            //Leo
            int n;
            byte[] bufferEntrada = new byte[2048];
            /*
            n = secureStreamCliente.read(bufferEntrada, 0, bufferEntrada.length);

            System.out.println("ReadCiph: " + n);
            if(n>0){
                String msg_r = new String(bufferEntrada, 0, n);
                System.out.println(msg_r);
            }
            */
            String msg_r = secureStreamCliente.readUTF();
            System.out.println("#: " + msg_r);
            
            secureStreamCliente.close();
            socketServicio.close();
            
        }catch(Exception e){
            System.err.println(e.toString());
            e.printStackTrace();
        }
    }
    
}
